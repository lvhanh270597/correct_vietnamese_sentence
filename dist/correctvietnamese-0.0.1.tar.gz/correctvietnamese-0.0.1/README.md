# Correct Vietnamese Sentence tool
* Description: Adding accents vietnamese sentence tool
* Examples:
** hom qua em đến truong ==> hôm qua em đến trường (26.334286 (ms))
** ngay xua em den nhu mot cơn gio ==> ngày xưa em đến như một cơn gió (20.843744 (ms))
** anh khong con yeu toi nua sao ==> anh không còn yêu tôi nữa sao (12.449741 (ms))
** anh di chet di ==> anh đi chết đi
* Author: Hanh. Le Van
